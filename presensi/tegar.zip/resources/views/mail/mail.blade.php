Email ini dikirim karena anda meminta untuk reset password anda. 
Silahkan masukkan token ini ke aplikasi untuk reset password anda.
<p>Reset Password</p>
<p>Token : {{ $token }}</p>
