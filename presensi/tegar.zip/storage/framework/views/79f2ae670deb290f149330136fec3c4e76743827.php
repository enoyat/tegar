<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- Jumbotron -->
    <div class="container">
        <div class="row">
            <div class="col-lg-1" style="padding: 5px">
                <img style="width: 50px; border-radius: 10px; display: block; " src="<?php echo e(asset('assets/img/icon.png')); ?>">
            </div>
            <div class="col-lg-11 mt-2">

                <b> E-PRESENSI</b><br>
                <SMALL>SISTEM INFORMASI PRESENSI</SMALL>
            </div>
        </div>
        <hr>
    </div>

    <div class="container">

        <div class="row">
            <div class="col-lg-8">
                <div class="row align-items-md-stretch">
                    <div class="col-md-12">
                        <div class="p-5  " style="background-color: rgb(180, 174, 182); border-radius:10px">
                            <h3 class="mt-4">E-PRESENSI</h3>
                            <p class="lead">SISTEM INFORMASI PRESENSI adalah sebuah sistem yang
                                digunakan untuk
                                    presensi pegawai secara online.</p>
                           
                        </div>
                    </div>

                </div>

            </div>
            <div class="col-lg-4">

                <div class="container">
                    <div class="row justify-content-center">
                        <div class="col-lg-12">
                            <div class="card  p-3">
                                <div class="card-header border-bottom-0" style="text-align: center">
                                    <div style="margin-top: 5px">LOGIN</div>
                                </div>
                                <?php if(session('errors')): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        ada kesalahan:
                                        <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                                            <span aria-hidden="true">×</span>
                                        </button>
                                        <ul>
                                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li><?php echo e($error); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </div>
                                <?php endif; ?>
                                <form method="POST" action="<?php echo e(route('login')); ?>">
                                    <?php echo csrf_field(); ?>
                                    <div class="card-body">
                                        
                                            <div class="form-group mb-4">
                                                <h6>Email</h6>
                                                <input id="email" type="email"
                                                    class="form-control form-control-login rounded-right <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    placeholder="Email" name="email" value="<?php echo e(old('email')); ?>" required
                                                    autocomplete="email">
                                                <div class="invalid-feedback">
                                                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <script>
                                                            Swal.fire({
                                                                icon: 'error',
                                                                title: 'Gagal Login!',
                                                                text: 'Cek email dan password!'
                                                            })
                                                        </script>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                            </div>
                                            <div class="form-group mb-4">
                                                <h6>Password</h6>
                                                <input id="password" type="password"
                                                    class="form-control form-control-login rounded-right <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                                    placeholder="Password" name="password" required
                                                    autocomplete="current-password">
                                                <div class="invalid-feedback">
                                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                        <script>
                                                            Swal.fire({
                                                                icon: 'error',
                                                                title: 'Gagal Login!',
                                                                text: 'Cek email dan password!'
                                                            })
                                                        </script>
                                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                                </div>
                                        </div>
                                         
                                           
                                            <button type="submit"
                                                class="btn btn-primary float-right rounded-pill w-50">Sign
                                                In</button>

                                            <?php if(Session::has('error')): ?>
                                                <div class="alert alert-danger">
                                                    <?php echo e(Session::get('error')); ?>

                                                </div>
                                            <?php endif; ?>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
    <script type="text/javascript">
        $('#reload').click(function() {
            $.ajax({
                type: 'GET',
                url: 'utility/reload-captcha',
                success: function(data) {
                    $(".captcha span").html(data.captcha);
                }
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master-login', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\GitHub\tegar\presensi\resources\views/auth/login.blade.php ENDPATH**/ ?>