<!-- Main Sidebar Container -->
<aside class="main-sidebar sidebar-dark-primary  elevation-4">
    <!-- Brand Logo -->
    <div class="brand-link">
        <img src="<?php echo e(asset('assets/img/icon.png')); ?>" class="brand-image" style="opacity: .8">
        <span class="brand-text font-weight-light">DASHBOARD</span>
    </div>

    <!-- Sidebar -->
    <div class="sidebar">
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu"
                data-accordion="false">
                <li class="nav-header">ADMIN</li>
                <li class="nav-item">
                    <a href="<?php echo e(route('administrator.home.index')); ?>"
                        class="nav-link shadow-none <?php echo e(request()->is('administrator/home*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-solid fa-cube"></i>
                        <p>Home</p>
                    </a>
                </li>


                <li class="nav-item">
                    <a href="#" class="nav-link <?php echo e(request()->is('laporan*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-reguler fa-user"></i>

                        <p>
                            Master Data
                            <i class="fas fa-angle-right right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="<?php echo e(route('pegawai.index')); ?>"
                                class="nav-link <?php echo e(request()->is('pegawai.index') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Data Pegawai</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="<?php echo e(route('lokasi.index')); ?>"
                                class="nav-link <?php echo e(request()->is('lokasi.index') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Lokasi</p>
                            </a>
                        </li>
                      
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('presensi.index')); ?>"
                        class="nav-link shadow-none <?php echo e(request()->is('presensi.*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-solid fa-cube"></i>
                        <p>Data Presensi</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('laporan.rpttransaction')); ?>"
                        class="nav-link shadow-none <?php echo e(request()->is('laporan.rpttransaction*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-solid fa-cube"></i>
                        <p>Laporan Presensi</p>
                    </a>
                </li>

                <li class="nav-item">
                    <a href="#" class="nav-link <?php echo e(request()->is('utility*') ? 'active' : ''); ?>">
                        <i class="nav-icon fas fa-reguler fa-user"></i>

                        <p>
                            Utiity
                            <i class="fas fa-angle-right right"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">

                        <li class="nav-item">
                            <a href="<?php echo e(route('utility.gantipassword')); ?>"
                                class="nav-link <?php echo e(request()->is('utility.gantipassword') ? 'active' : ''); ?>">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Update Password</p>
                            </a>
                        </li>

                    </ul>
                </li>

                <li class="nav-header">LOGOUT</li>
                <li class="nav-item">
                    <a class="nav-link shadow-none" href="<?php echo e(route('logout')); ?>"
                        onclick="event.preventDefault(); document.getElementById('logout-form').submit();">
                        <i class="fas fa-power-off nav-icon"></i>
                        <p><?php echo e(__('Logout')); ?></p>
                    </a>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                        <?php echo csrf_field(); ?>
                    </form>
                </li>
            </ul>
        </nav>
        <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
</aside>
<?php /**PATH C:\Users\ASUS\Documents\GitHub\tegar\presensi\resources\views/template/partials/sidebar-administrator.blade.php ENDPATH**/ ?>