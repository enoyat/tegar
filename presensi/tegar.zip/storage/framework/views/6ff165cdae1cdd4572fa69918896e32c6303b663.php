<?php $__env->startSection('contents'); ?>
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1>Data presensi</h1>
                    </div>
                </div>
            </div>
        </section>

        <section class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-12">

                        <a href="<?php echo e(route('presensi.index')); ?>">
                            <div id="viewData" class="btn btn-info">Refresh</div>
                        </a>
                        <a href="<?php echo e(route('presensi.add')); ?>">
                            <div id="viewData" class="btn btn-info">Tambah presensi</div>
                        </a>
                        <form action="<?php echo e(route('presensi.index')); ?>" method="GET">
                            <div class="form-group>
                                <label for="">Tampilkan berdasar Tanggal </label>
                                <input type="date" name="tanggal" id="tanggal" value="<?php echo e(request()->get('tanggal')); ?>" required="required" title="">

                                <button type="submit" class="btn btn-primary" id="btncetak"> View</button>
                            </div>
                        </form>

                        <br>
                        <br>

                        <table class="table  table-hover table-responsive" id='mydata'>
                            <thead>
                                <tr>

                                    <th>
                                        No
                                    </th>
                                    <th>
                                        Nama Pegawai
                                    </th>
                                    <th>
                                        NIK
                                    </th>
                                    <th>
                                        Status Presensi
                                    </th>
                                    <th>
                                        Tanggal
                                    </th>
                                    <th>
                                        Jam Datang
                                    </th>
                                    <th>
                                        Jam Pulang
                                    </th>
                                    <th>
                                        Aksi
                                    </th>

                                </tr>
                            </thead>
                            <tbody>
                                <?php $i=1; ?>
                                <?php $__currentLoopData = $presensis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo $i; ?></td>
                                        <td><?php echo $key->pegawai->namapegawai; ?></td>
                                        <td><?php echo $key->pegawai->nik; ?></td>
                                        <td><?php echo $key->statuspresensi; ?></td>
                                        <td><?php echo $key->tanggal; ?></td>
                                        <td><?php echo $key->jamdatang; ?></td>
                                        <td><?php echo $key->jampulang; ?></td>
                                        <td>



                                            <div style="display: inline;  float:left; width:35px">
                                                <a href="<?php echo e(route('presensi.edit', $key->idpresensi)); ?>">
                                                    <div id='soalBtn' class='btn btn-warning btn-xs' title="Edit">Edit</div>
                                                </a>
                                            </div>
                                            <div style="display: inline;  float:right; width:35px">
                                                <form action="<?php echo e(route('presensi.delete', $key->idpresensi)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-sm btn-danger"
                                                        onclick="return confirm('Hapus presensi ini?');"><i
                                                            class="fa fa-trash" aria-hidden="true"></i></button>
                                                </form>
                                            </div>
                                        </td>
                                        </td>
                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <br>
                        <br>
                    </div>

                </div>
            </div>
        </section>
    </div>
    <script>
        $(function() {
            $('#mydata').DataTable({
                'paging': true,
                'lengthChange': true,
                'searching': true,
                'ordering': true,
                'info': true,
                'autoWidth': false
            })
        })

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template.master-dashboard-administrator', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ASUS\Documents\GitHub\tegar\presensi\resources\views/presensi/index.blade.php ENDPATH**/ ?>